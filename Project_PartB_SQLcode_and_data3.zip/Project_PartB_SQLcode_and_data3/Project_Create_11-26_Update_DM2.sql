CREATE TABLE college (
  college_name varchar(30), 
  department varchar(30),
  primary key(college_name,department),
  key (department)
);

LOAD DATA LOCAL INFILE "C:/Users/Dawson/Documents/Dawson/College/Bellevue College/CS331/GroupProject/Project_PartB_PlaceholderData - College.csv"
INTO TABLE college
FIELDS ENCLOSED BY '"' TERMINATED BY ',' LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

CREATE TABLE person (
  name varchar(30),
  student_id   integer(9) not null,
  ssn        integer(9),
  gender char,
  spouse_id integer(9),
  address varchar(100),
  phone varchar(20),
  year_of_study varchar(7),
  fhID integer(9),
  major varchar(30),
  primary key (student_id)
);

LOAD DATA LOCAL INFILE "C:/Users/Dawson/Documents/Dawson/College/Bellevue College/CS331/GroupProject/Project_PartB_PlaceholderData - Person.csv"
INTO TABLE person
FIELDS ENCLOSED BY '"' TERMINATED BY ',' LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

alter table person add foreign key (fhID) references person(student_id) on delete cascade;
alter table person add foreign key (spouse_id) references person(student_id) on delete cascade;

CREATE TABLE resident (
  resident_id integer(9),
  amount_paid integer(12),
  amount_owed integer(12),
  primary key(resident_id),
  password varchar(20),
  foreign key (resident_id) references person(student_id) on delete cascade
);

LOAD DATA LOCAL INFILE "C:/Users/Dawson/Documents/Dawson/College/Bellevue College/CS331/GroupProject/Project_PartB_PlaceholderData - Resident.csv"
INTO TABLE resident
FIELDS ENCLOSED BY '"' TERMINATED BY ',' LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

CREATE TABLE unit_type(
  type_id int(3) not null,
  apartment_suite varchar(9),
  bedroom_num int(3),
  people_num int(3),
  married_ok boolean,
  unit_price int(4),
  primary key (type_id)
);

LOAD DATA LOCAL INFILE "C:/Users/Dawson/Documents/Dawson/College/Bellevue College/CS331/GroupProject/Project_PartB_PlaceholderData - Unit_Type.csv"
INTO TABLE unit_type
FIELDS ENCLOSED BY '"' TERMINATED BY ',' LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

CREATE TABLE unit (
  address varchar(100) not null, 
  building_num integer(1),
  unit_type int(3),
  unit_num integer(4), 
  vacant_date date,
  primary key (address),
  key (building_num),
  key (unit_num),
  foreign key (unit_type) references unit_type(type_id) on delete cascade
);

LOAD DATA LOCAL INFILE "C:/Users/Dawson/Documents/Dawson/College/Bellevue College/CS331/GroupProject/Project_PartB_PlaceholderData - Unit.csv"
INTO TABLE unit
FIELDS ENCLOSED BY '"' TERMINATED BY ',' LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

CREATE TABLE applicant (
  applicant_id 	integer(9) not null,
  roommate_id 	integer(9),
  application_date date,
  application_fee boolean,
  password varchar(20),
  primary key (applicant_id),
  foreign key (applicant_id) references person(student_id) on delete cascade,
  foreign key (roommate_id) references person(student_id) on delete cascade
  );
  
LOAD DATA LOCAL INFILE "C:/Users/Dawson/Documents/Dawson/College/Bellevue College/CS331/GroupProject/Project_PartB_PlaceholderData - Applicant.csv"
INTO TABLE applicant
FIELDS ENCLOSED BY '"' TERMINATED BY ',' LINES TERMINATED BY '\n'
IGNORE 1 ROWS;
  
CREATE TABLE unit_preference(
  applicant_id integer(9) not null,
  building_pref integer(1),
  unit_pref int(3),
  primary key(applicant_id, building_pref, unit_pref)
);

LOAD DATA LOCAL INFILE "C:/Users/Dawson/Documents/Dawson/College/Bellevue College/CS331/GroupProject/Project_PartB_PlaceholderData - Unit_Preference.csv"
INTO TABLE unit_preference
FIELDS ENCLOSED BY '"' TERMINATED BY ',' LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

alter table unit_preference add foreign key (building_pref) references unit(building_num) on delete cascade;
alter table unit_preference add foreign key (unit_pref) references unit_type(type_id) on delete cascade;

CREATE TABLE admin (
  name varchar(30),
  admin_id integer(9) not null,
  admin_ssn integer(9)not null,
  password varchar(30),
  dept varchar(30),
  phone varchar(20),
  gender char,
  job_title varchar(30),
  primary key(admin_id)
);

LOAD DATA LOCAL INFILE "C:/Users/Dawson/Documents/Dawson/College/Bellevue College/CS331/GroupProject/Project_PartB_PlaceholderData - Admin.csv"
INTO TABLE admin
FIELDS ENCLOSED BY '"' TERMINATED BY ',' LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

alter table admin add foreign key (dept) references college(department) on delete cascade;

CREATE TABLE maintenance_request (
  address varchar(100),
  resident_id integer(9),
  submission_date date,
  problem_description varchar(500),
  fix_date varchar(12),
  employee_resp varchar(30),
  due_date date,
  primary key (address, submission_date, resident_id)
);

LOAD DATA LOCAL INFILE "C:/Users/Dawson/Documents/Dawson/College/Bellevue College/CS331/GroupProject/Project_PartB_PlaceholderData - Maintenance_Requests.csv"
INTO TABLE maintenance_request
FIELDS ENCLOSED BY '"' TERMINATED BY ',' LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

alter table maintenance_request add foreign key (address) references unit(address) on delete cascade;
alter table maintenance_request add foreign key (resident_id) references person(student_id) on delete cascade;

CREATE TABLE person_belongs(
  student_id integer(9),
  college_name varchar(30),
  department_name varchar(30),
  primary key(student_id)
);

LOAD DATA LOCAL INFILE "C:/Users/Dawson/Documents/Dawson/College/Bellevue College/CS331/GroupProject/Project_PartB_PlaceholderData - Person_Belongs.csv"
INTO TABLE person_belongs
FIELDS ENCLOSED BY '"' TERMINATED BY ',' LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

alter table person_belongs add foreign key (student_id) references person(student_id) on delete cascade;
alter table person_belongs add foreign key (college_name) references college(college_name) on delete cascade;
alter table person_belongs add foreign key (department_name) references college(department) on delete cascade;

DROP TABLE person_belongs;
DROP TABLE maintenance_request;
DROP TABLE admin;
DROP TABLE unit_preference;
DROP TABLE applicant;
DROP TABLE unit;
DROP Table unit_type;
DROP TABLE resident;
DROP TABLE person;
DROP TABLE college;